from django.db import models

from django.db.models import signals
from django.template.defaultfilters import slugify
import json

class Base(models.Model):
    criado = models.DateField('Data de Criação', auto_now_add=True)
    modificado = models.DateField('Data de Atualização', auto_now=True)
    ativo = models.BooleanField('Ativo?', default=True)

    class Meta:
        abstract = True

class Casos(Base):
    caso = models.CharField('Titulo', max_length=100)
    descricao = models.CharField('Descrição do caso', max_length=100)
    valor = models.DecimalField('Valor da doação', max_digits=8, decimal_places=2)

    def __str__(self):
        return self.caso

def casos_pre_save(signal, instance, sender, **kwargs):
    instance_slug = slugify(instance.caso)

signals.pre_save.connect(casos_pre_save, sender=Casos)



class Herois(Base):
    nome = models.CharField('Nome da ONG', max_length=100)
    email = models.EmailField('E-mail', max_length=100)
    whatsapp = models.CharField('WhatsApp', max_length=20)
    cidade = models.CharField('Cidade', max_length=100)

    
    def __str__(self):
        return self.nome

def herois_pre_save(signal, instance, sender, **kwargs):
    instance_slug = slugify(instance.nome)

signals.pre_save.connect(herois_pre_save, sender=Herois)



class Email(Base):
    nome = models.CharField('Nome', max_length=100)
    email = models.EmailField('E-mail', max_length=100)
    assunto = models.CharField('Assunto',max_length=100)
    mensagem = models.CharField('Mensagem', max_length=200)

        
    def __str__(self):
        return self.nome

def emails_pre_save(signal, instance, sender, **kwargs):
    instance_slug = slugify(instance.nome)

signals.pre_save.connect(emails_pre_save, sender=Email)



    
