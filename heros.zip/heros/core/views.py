from django.shortcuts import render, redirect
from django.contrib import messages

from .forms import HeroisModelForm, CasosModelForm, EmailModelForm
from .models import Casos, Email

def index(request):
    context = {
        'caso': Casos.objects.all() 
    }
    return render(request,  'index.html', context)


def contato(request):
    if str(request.user) != 'AnonymousUser':
        print(f'Usuário: {request.user} LOGADO')
        
        if str(request.method) == 'POST':
            form = HeroisModelForm(request.POST, request.FILES)
            if form.is_valid():
                her = form.save(commit=False)
                form.save()


                print('Cadastaro realizado com sucesso')
                print(f'Nome: {her.nome}')
                print(f'E-mail: {her.email}')
                print(f'WhatsApp: {her.whatsapp}')
                print(f'Cidade: {her.cidade}')

                messages.success(request, 'Cadastro enviado com sucesso!')
                form = HeroisModelForm()
            else:
                messages.error(request, 'Erro ao enviar e-mail')
        context = {
            'form': HeroisModelForm
        }
        return render(request, 'contato.html', context)
    else:
        return redirect('login')


def ongs(request):
    if str(request.user) != 'AnonymousUser':
        print(f'Usuário: {request.user} LOGADO')
        if str(request.method) == 'POST':
            form = CasosModelForm(request.POST, request.FILES)
            if form.is_valid():
                cas = form.save(commit=False)
                form.save()

                print(f'Caso: {cas.caso}')
                print(f'Descricao: {cas.descricao}')
                print(f'Valor: {cas.valor}')
                
                messages.success(request, 'Caso salvo com Sucesso.')
                form = CasosModelForm()
            else:
                messages.error(request, 'Erro ao salvar o Caso.')
        else:
            form = CasosModelForm()
        context = {
            'form': form
        }
        return render(request, 'ongs.html', context)
    else:
        return redirect('login')



def email(request):
    if str(request.user) != 'AnonymousUser':
        print(f'Usuário: {request.user} LOGADO')

        form = EmailModelForm(request.POST or None)

        if str(request.method) == 'POST':
            if form.is_valid():
                form.send_mail()

                messages.success(request, 'Email enviado com sucesso!')
                form = EmailModelForm()
            else:
                messages.error(request, 'Erro ao enviar e-mail')
        context = {
            'form': form
        }
        return render(request, 'email.html', context)
    else:
        return redirect('login')

def login(request):
    return render(request, 'login.html')

    