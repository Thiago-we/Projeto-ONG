from django.contrib import admin


from .models import Casos

@admin.register(Casos)
class CasosAdmin(admin.ModelAdmin):
    list_display = ('caso', 'descricao', 'valor', 'criado', 'modificado', 'ativo')


