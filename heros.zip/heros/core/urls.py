
from django.urls import path

from.views import index, contato, ongs, email, login

urlpatterns = [
    path('index/', index, name='index'),
    path('contato/', contato, name='contato'),
    path('ongs/', ongs, name='ongs'),
    path('email/', email, name='email'),
    path('login/', login, name='login'),
]








